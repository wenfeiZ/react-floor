import * as TYPES from '../action-types';
import api from '../../api/index';
export default {
	
};