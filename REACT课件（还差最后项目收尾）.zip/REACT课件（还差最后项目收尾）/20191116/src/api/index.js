import product from './product';
import personal from './personal';
import cart from './cart';
const api = {
	product,
	personal,
	cart
};
export default api;