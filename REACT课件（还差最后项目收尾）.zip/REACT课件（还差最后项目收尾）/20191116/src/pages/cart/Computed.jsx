import React from 'react';
import './Computed.less';
export default function Computed(props) {
	return <div className="computedBox">
		<div className="check">
			<i className="active"></i>
			<span>全选</span>
		</div>
		<div className="result">
			<p>合计：<span>￥2498</span></p>
			<button>去支付</button>
		</div>
	</div>;
}