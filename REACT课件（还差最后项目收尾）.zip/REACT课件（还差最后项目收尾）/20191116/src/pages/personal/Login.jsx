import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import './Login.less';
import api from '../../api/index';
import actions from '../../store/actions/index';

class Login extends React.Component {
	state = {
		// 登录的方式  2短信验证码   1账号密码
		type: 2,
		// 存储账号密码或者手机号验证码
		account: '',
		password: '',
		// 倒计时
		isRun: false,
		runTime: 30
	};
	render() {
		let { type, account, password, isRun, runTime } = this.state;
		return <section className="loginBox">
			<div className="header">
				<h4>欢迎登录小米有品</h4>
			</div>

			<div className="main">
				{
					type === 2 ? <>
						<div className="inpBox">
							<input type="text" placeholder="手机号码"
								value={account}
								onChange={ev => {
									this.setState({ account: ev.target.value })
								}} />
						</div>
						<div className="inpBox">
							<input type="text" placeholder="短信验证码"
								className='short'
								value={password}
								onChange={ev => {
									this.setState({ password: ev.target.value })
								}} />

							<a className={isRun ? 'noClick' : ''}
								onClick={this.sendCode}>
								{isRun ? `${runTime}S后重新获取` : `获取验证码`}
							</a>
						</div>
					</> : <>
							<div className="inpBox">
								<input type="text" placeholder="用户名/手机号码" value={account}
									onChange={ev => {
										this.setState({ account: ev.target.value })
									}} />
							</div>
							<div className="inpBox">
								<input type="password" placeholder="密码"
									value={password}
									onChange={ev => {
										this.setState({ password: ev.target.value })
									}} />
							</div>
						</>
				}
				<button className="submit"
					onClick={this.handleLogin}>
					立即登录
				</button>
				<span className='changeBtn'
					onClick={this.handleChange}>
					{type === 1 ? '用户名密码登录' : '短信验证码登录'}
				</span>
			</div>

			<div className="register">
				<Link to='/personal/register'>立即注册</Link>
				|
				<a>忘记密码</a>
			</div>

			<div className="other">
				<span>其他登录方式</span>
				<div>
					<a></a>
					<a></a>
					<a></a>
				</div>
			</div>

			<div className="footer">
				<span>首页</span>|<span>简体</span>|<span>English</span>|<span>常见问题</span>|<span>隐私政策</span>
			</div>
		</section>;
	}
	handleChange = () => {
		let { type } = this.state;
		this.setState({
			type: type === 1 ? 2 : 1,
			account: '',
			password: ''
		});
	};
	sendCode = async () => {
		let { account, isRun } = this.state;
		if (isRun) return;
		if (!/^1\d{10}$/.test(account)) {
			window.alert('手机号码格式不正确~~');
			return;
		}
		let data = await api.personal.phone(account);
		if (parseInt(data.code) !== 0) {
			window.alert('当前手机号还没有被注册，请您先注册~~');
			return;
		}
		data = await api.personal.code(account);
		if (parseInt(data.code) !== 0) {
			window.alert('发送失败，请稍后再试~~');
			return;
		}
		this.setState({ isRun: true });
		this.codeTimer = setInterval(() => {
			let time = this.state.runTime;
			time--;
			if (time === 0) {
				clearInterval(this.codeTimer);
				this.setState({
					isRun: false,
					runTime: 30
				});
				return;
			}
			this.setState({ runTime: time });
		}, 1000);
	};
	handleLogin = async () => {
		let { type, account, password } = this.state;
		if (type === 2) {
			if (!/^1\d{10}$/.test(account)) {
				window.alert('手机号码格式不正确~~');
				return;
			}
			if (!/^\d{6}$/.test(password)) {
				window.alert('验证码格式不正确~~');
				return;
			}
		} else {
			if (account.length === 0) {
				window.alert('账号不能为空~~');
				return;
			}
			if (!/^\w{6,16}$/.test(password)) {
				window.alert('密码格式不正确~~');
				return;
			}
		}
		let data = await api.personal.loginPOST(account, password, type);
		if (parseInt(data.code) !== 0) {
			window.alert(`登录失败，${type === 2 ? '验证码输入有误！' : '账号密码不匹配！'}`);
			return;
		}
		window.alert('恭喜您登录成功！~~', {
			handled: () => {
				// 把登录态和基本信息存储到redux中
				this.props.loginSuccess(data.data);
				// 路由跳转
				const search = this.props.location.search;
				if (search && search.includes('noback')) {
					this.props.history.push('/personal');
				} else {
					this.props.history.go(-1);
				}
			}
		});
	};
}

export default connect(null, actions.personal)(Login);