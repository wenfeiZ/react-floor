import taskAction from './taskAction';
export default {
	task: taskAction
};