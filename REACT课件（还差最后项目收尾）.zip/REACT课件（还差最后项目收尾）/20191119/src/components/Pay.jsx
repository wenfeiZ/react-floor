import React from 'react';
import './Pay.less';
export default function Pay(props) {
	return <div className="payBox">
		<a className="closeBtn">关闭</a>
		<h4>请输入支付密码（六位数字）</h4>
		<div className="center">
			<input type="password" disabled />
			<input type="password" disabled />
			<input type="password" disabled />
			<input type="password" disabled />
			<input type="password" disabled />
			<input type="password" disabled />
		</div>
		<div className="keyBox clearfix">
			<span>1</span>
			<span>2</span>
			<span>3</span>
			<span>4</span>
			<span>5</span>
			<span>6</span>
			<span>7</span>
			<span>8</span>
			<span>9</span>
			<span>0</span>
			<span>删除</span>
			<span>确认</span>
		</div>
	</div>;
}