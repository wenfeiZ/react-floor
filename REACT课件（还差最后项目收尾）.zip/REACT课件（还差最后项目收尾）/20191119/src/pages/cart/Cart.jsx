import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import './Cart.less';
import Recomend from './Recoment';
import Computed from './Computed';
import HeaderNav from '../../components/HeaderNav';
import Pay from '../../components/Pay';
import actions from '../../store/actions/index';

class Cart extends React.Component {
	componentWillMount() {
		let baseInfo = this.props.baseInfo;
		if (!baseInfo) {
			this.props.syncLoginInfo();
		}
	}
	render() {
		let { baseInfo, orderList, syncOrderList } = this.props;
		if (baseInfo && !orderList) {
			syncOrderList();
		}
		if (orderList) {
			orderList = orderList.filter(item => {
				return parseInt(item.state) === 1;
			});
		}

		return <section className="cartBox">
			<HeaderNav title="购物车">
				<span>编辑</span>
			</HeaderNav>

			{!baseInfo ? <div className="noTip">
				<i></i>
				您还没有登录~
				<Link to='/personal/login'>立即登录</Link>
			</div> : (
					!orderList || orderList.length === 0 ? <div className="noTip">
						<i></i>
						购物车该没有信息哦，先去逛逛吧~
					</div> : <div className="list">
							{orderList.map(item => {
								return <Link to={'/detail/' + item.pid} className="clearfix" key={item.id}>
									<i className="check active"></i>
									<div className="pic">
										<img src={item.info.pic} alt="" />
									</div>
									<div className="desc">
										<p>{item.info.title}</p>
										<p>￥{item.info.discount}</p>
									</div>
									<div className="count">
										<i className="minus disable"></i>
										<input type="number" value={item.count} disabled />
										<i className="plus"></i>
									</div>
								</Link>
							})}
						</div>
				)
			}

			<Recomend />
			<Computed checked={true} />

			{/* <Pay carts={[1, 2, 3]} /> */}
		</section>;
	}
}
export default connect(state => {
	return {
		...state.personal,
		...state.cart
	}
}, {
	...actions.personal,
	...actions.cart
})(Cart);