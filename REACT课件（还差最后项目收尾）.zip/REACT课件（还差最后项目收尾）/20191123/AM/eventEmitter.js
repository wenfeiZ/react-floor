/*
 * 发布订阅设计模式 
 */
const EventEmitter = require('events');
const myEmitter = new EventEmitter();
//=>基于ON的方式，自定义事件和向事件池中追加要处理的方法
myEmitter.on('A', () => {
	console.log(1);
});
myEmitter.on('A', () => {
	console.log(2);
});
myEmitter.on('B', () => {
	console.log(3);
});
//=>基于EMIT触发指定自定义事件中的方法执行
myEmitter.emit('A');