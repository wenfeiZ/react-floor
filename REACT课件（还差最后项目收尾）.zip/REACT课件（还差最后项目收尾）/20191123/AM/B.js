const A = require('./A');

function avgFn(...args) {
	args.sort((a, b) => a - b);
	args = args.slice(1, args.length - 1);
	// 求和：需要调取A模块中的SUM
	let result = A.sum(...args);
	return (result / args.length).toFixed(2);
}

module.exports = {
	avgFn
};