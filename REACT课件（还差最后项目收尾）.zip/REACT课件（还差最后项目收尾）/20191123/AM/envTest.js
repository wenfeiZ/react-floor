// process.env.NODE_ENV ： 设置NODE的全局环境变量
// =>webpack区分开发和生产环境
const env = process.env.NODE_ENV || 'dev';
if (env === 'dev') {
	console.log('我是开发环境~~');
} else {
	console.log('我是生产环境~~');
}