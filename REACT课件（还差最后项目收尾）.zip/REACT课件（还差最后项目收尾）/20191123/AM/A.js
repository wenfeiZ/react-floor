function sum(...args) {
	// return eval(args.join('+'));
	return args.reduce((result, item) => {
		return result + item;
	}, 0);
}
module.exports = {
	sum
};