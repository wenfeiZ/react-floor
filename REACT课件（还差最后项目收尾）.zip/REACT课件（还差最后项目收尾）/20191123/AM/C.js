// import B from './B';  //=>NODE不支持ES6 Module模式
//=>需要调取B中的avgFn 
const {
	avgFn
} = require('./B'); //=>导入自己写的模块一定要加地址，如果写成 require('B') 它是先找安装的第三方模块，没有再找内置模块...
let result = avgFn(99, 65, 98, 78, 89, 64, 57);
console.log(result);