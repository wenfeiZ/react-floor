/* 创建STORE容器 */
import {
	createStore
} from '../my-redux';
import reducer from './reducers/reducer';
const store = createStore(reducer);
export default store;