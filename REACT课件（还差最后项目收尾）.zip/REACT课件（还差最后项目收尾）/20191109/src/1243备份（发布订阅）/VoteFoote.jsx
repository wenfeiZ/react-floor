import React from 'react';

export default class VoteFoote extends React.Component {
	render() {
		let { eventBus } = this.props;
		return <div>
			<button onClick={ev => {
				eventBus.$emit('zhufeng', 'SUP');
			}}>支持</button>
			<button onClick={ev => {
				eventBus.$emit('zhufeng', 'OPP');
			}}>反对</button>
		</div>;
	}
}