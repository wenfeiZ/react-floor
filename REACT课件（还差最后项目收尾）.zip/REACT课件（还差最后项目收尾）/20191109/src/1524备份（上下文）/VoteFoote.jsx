import React from 'react';
import PropTypes from 'prop-types';

export default class VoteFoote extends React.Component {
	// 获取上下文中的信息
	static contextTypes = {
		handle: PropTypes.func
	};
	render() {
		let { handle } = this.context;
		return <div>
			<button onClick={ev => {
				handle('SUP');
			}}>支持</button>
			<button onClick={ev => {
				handle('OPP');
			}}>反对</button>
		</div>;
	}
}