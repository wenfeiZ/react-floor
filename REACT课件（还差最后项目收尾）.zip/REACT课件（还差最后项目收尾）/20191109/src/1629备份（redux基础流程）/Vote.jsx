import React from 'react';
import VoteHead from './VoteHead';
import VoteMain from './VoteMain';
import VoteFoote from './VoteFoote';

const ThemeContext = React.createContext();
window.ThemeContext = ThemeContext;
export default class Vote extends React.Component {
	render() {
		return <ThemeContext.Provider value={{
			store: this.props.store
		}}>
			<VoteHead />
			<VoteMain />
			<VoteFoote />
		</ThemeContext.Provider>;
	}
}