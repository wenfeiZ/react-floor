import React from 'react';
import action from './store/actions/action';
import { connect } from './my-react-redux';
class VoteFoote extends React.Component {
	render() {
		let { changeSupNum, changeOppNum } = this.props;
		return <>
			<button onClick={ev => {
				changeSupNum();
			}}>支持</button>
			<button onClick={ev => {
				changeOppNum();
			}}>反对</button>
		</>;
	}
}
export default connect(null, action.vote)(VoteFoote);

/*
{
	changeSupNum() {
		return {
			type: TYPES.VOTE_SUPPORT
		};
	},
	changeOppNum() {
		return {
			type: TYPES.VOTE_OPPOSE
		};
	}
}
*/
// react-redux帮我们把action-creators变为派发的形式 
/* function mapDispatchToProps(dispatch) {
	//dispatch => store.dispatch
	return {
		changeSupNum() {
			dispatch(action.vote.changeSupNum());
		},
		changeOppNum() {
			dispatch(action.vote.changeOppNum());
		}
	}
} */
