import React from 'react';
import action from './store/actions/action';

export default class VoteFoote extends React.Component {
	render() {
		return <>
			<button onClick={ev => {
				this.props.store.dispatch(action.vote.changeSupNum());
			}}>支持</button>
			<button onClick={ev => {
				this.props.store.dispatch(action.vote.changeOppNum());
			}}>反对</button>
		</>;
	}
}