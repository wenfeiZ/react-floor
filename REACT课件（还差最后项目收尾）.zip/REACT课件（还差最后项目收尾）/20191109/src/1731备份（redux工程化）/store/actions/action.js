/* 合并ACTION */
import voteAction from './voteAction';
const action = {
	vote: voteAction
};
export default action;