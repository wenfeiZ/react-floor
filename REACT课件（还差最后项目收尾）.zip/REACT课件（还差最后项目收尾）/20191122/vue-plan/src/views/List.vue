<template>
    <div class="form-horizontal">
      <div class="form-group">
        <div class="col-md-6">
          <label for="date">日期</label>
          <input type="date" id="date" class="form-control"  v-model="date" placeholder="请选择日期" >
        </div>
        <div class="col-md-6">
          <label for="time">时间</label>
          <input type="number" id="time" class="form-control"  v-model.number="timer" placeholder="请选择时间" >
        </div>
      </div>
      <div class="form-group">
        <div class="col-md-12">
          <textarea  class="form-control" v-model="comment"  placeholder="请输入信息"></textarea >
        </div>
      </div>
      <div class="form-group">
        <div class="col-md-12">
          <button class="btn btn-primary" @click="save">保存</button>
        </div>
      </div>
      <hr>

    </div>
</template>
<script>
import {mapActions} from 'vuex';
import * as types from '@/store/types';
// console.log(mapActions([types.SAVE_PLAN]));
export default {
    data(){
        return {
            date:"",
            timer:'',
            comment:''
        }
    },
    methods:{
        ...mapActions([types.SAVE_PLAN,types.INCREASE_TIME]),
        save(){
            let plan ={
                date:this.date,
                timer:this.timer,
                comment:this.comment
            }
            this[types.SAVE_PLAN](plan);
            this[types.INCREASE_TIME](this.timer)
            this.$router.push('/time');
            //this.$store.dispath('save_plan',plan)

        }
    }
}
</script>