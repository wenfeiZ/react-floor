<template>
  <div>
  <div class="jumbotron">
  <h2>亲~开始计划之旅吧！！！</h2>
  <router-link tag="button" class="btn btn-primary" to="/time">创建任务</router-link>

</div>
  </div>
</template>