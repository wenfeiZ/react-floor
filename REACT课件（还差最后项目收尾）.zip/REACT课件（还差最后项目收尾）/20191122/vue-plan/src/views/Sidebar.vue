<template>
  <div>
    <div class="panel panel-default">
      <div class="panel-heading"><h3>计划总时长</h3></div>
      <div class="panel-body">{{totalTime | changeTimer}}时间</div>
    </div>
  </div>
</template>
<script>
import {mapState} from 'vuex';
export default {
    computed:{
        ...mapState(['totalTime'])
    },
    filters:{
        changeTimer(val){
            return val.toFixed(2)
        }
    }
}
</script>