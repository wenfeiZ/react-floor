<template>
  <div>
      <router-link to="/time/list" class="btn btn-danger" v-show="$route.path=='/time'">创建</router-link>
      <h3 v-show="$route.path=='/time/list'">创建</h3>
      <router-view></router-view>

      <ul class="list-group">
        <li class="list-group-item" v-for="(list,index) in lists" :key="index">
          <div class="row">
            <div class="col-md-2 text-center" >
              <img  alt="" :src="list.avatar" class="img img-circle img-responsive">
              <p>{{list.name}}</p>
            </div>
            <div class="col-md-3">
              <div class="time-block">
                <div>
                  <i class="glyphicon glyphicon-time"></i>
                  {{list.timer}}小时
                </div>
                <label class="label-primary label">
                  <i class="glyphicon-calendar glyphicon"></i>
                  {{list.date}}
                </label>
              </div>
            </div>
            <div class="col-md-6">
              <div class="comment">
               {{list.comment}}
              </div>
            </div>
            <div class="col-md-1">
              <button class="btn btn-danger" >&times;</button>
            </div>
          </div>
        </li>
      </ul>
  </div>
</template>
<script>
import {mapState} from 'vuex';
export default {
        computed:{
            ...mapState(['lists'])
        }
}
</script>
 <style scoped>
  .time-block{
    line-height: 50px;
  }
  .comment{
    padding: 20px;
  }
  li{
    margin: 10px 0px;
  }
  .add{
    font-size: 20px;
    line-height: 40px;
    color: purple;
  }
</style>