export const SAVE_PLAN = 'save_plan'
export const INCREASE_TIME = 'increase_time'