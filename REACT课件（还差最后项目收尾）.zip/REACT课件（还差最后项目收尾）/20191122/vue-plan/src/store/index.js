import Vue from 'vue'
import Vuex from 'vuex'
import * as types from '@/store/types';
Vue.use(Vuex)
  function  vuexlocal(){
      return function(store){
         let local = JSON.parse(localStorage.getItem('myvuex'))||store.state
          store.replaceState(local);
          store.subscribe((mutation,state)=>{
           
            let newState = JSON.parse(JSON.stringify(state));
            localStorage.setItem('myvuex',JSON.stringify(newState));
          })
      }
  }
export default new Vuex.Store({
  state: {
    lists:[],
    totalTime:0
  },
  mutations: {
    [types.SAVE_PLAN](state,plan){
      Object.assign(plan,{avatar:'http://f11.baidu.com/it/u=2754208607,630952272&fm=72',name:'zf'})
      state.lists.push(plan);
    },
    [types.INCREASE_TIME](state,time){
      state.totalTime += time;
    }
  },
  actions: {
      [types.SAVE_PLAN]({commit},obj){
        commit(types.SAVE_PLAN,obj)
      },
      [types.INCREASE_TIME]({commit},time){
        commit(types.INCREASE_TIME,time)
      }
  },
  modules: {
  },
  plugins:[vuexlocal()]
})
