<template>
  <div>
    <Navbar></Navbar>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="col-md-3">
            <Sidebar></Sidebar>
          </div>
          <div class="col-md-9">
            <transition enter-active-class="animated zoomIn" leave-active-class="aniamted zoomOut">
              <router-view></router-view>
            </transition>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Navbar from '@/views/Navbar';
import Sidebar from '@/views/Sidebar';
export default {
    components:{
      Navbar,
      Sidebar
    }
}
</script>