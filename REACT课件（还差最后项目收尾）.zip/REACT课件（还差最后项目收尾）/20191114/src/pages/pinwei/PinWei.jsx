import React from 'react';
export default function PinWei(props) {
	return <>
		品味
	</>;
}