import React from 'react';
export default function Category(props) {
	return <>
		分类
	</>;
}