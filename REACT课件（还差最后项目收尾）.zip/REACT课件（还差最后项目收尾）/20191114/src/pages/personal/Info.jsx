import React from 'react';
export default function Info(props) {
	return <>
		个人中心首页
	</>;
}