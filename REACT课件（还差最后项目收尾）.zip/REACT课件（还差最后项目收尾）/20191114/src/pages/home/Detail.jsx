import React from 'react';
export default function Detail(props) {
	console.log(props);
	return <>
		产品详情
	</>;
}