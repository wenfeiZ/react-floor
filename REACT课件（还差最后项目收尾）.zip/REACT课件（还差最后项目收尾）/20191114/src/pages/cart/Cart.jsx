import React from 'react';
export default function Cart(props) {
	return <>
		购物车
	</>;
}