const express = require('express'),
	route = express.Router();

module.exports = route;