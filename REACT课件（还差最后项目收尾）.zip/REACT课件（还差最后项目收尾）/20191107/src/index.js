import React from 'react';
import ReactDOM from 'react-dom';
import Clock from './Clock';
import Input from './Input';
import Test from './Test';


ReactDOM.render(<>
	{/* <Clock m={1} x='pass'/> */}
	{/* <Input /> */}
	<Test />
</>, document.getElementById('root'));