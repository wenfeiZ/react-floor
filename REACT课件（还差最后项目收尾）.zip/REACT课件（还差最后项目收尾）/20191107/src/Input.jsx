import React from 'react';

/*
 * 受控组件：受状态管控的组件 =>数据驱动视图渲染
 * 非受控组件： 不受状态管控的组件（直接操作DOM =>ref）
 */
export default class Input extends React.Component {
	render() {
		return <div>
			{/* <input type="text" ref='inpBox' /> */}
			{/* <input type="text" ref={element => {
				// element当前的元素对象
				this.INP = element;
			}} /> */}

			<input type="text" ref={x => this.inp = x} />
		</div>;
	}
	componentDidMount() {
		// console.log(this.refs); //=>{inpBox:input}
		// this.refs.inpBox.focus();

		this.inp.focus();
	}
}